#!/bin/bash
curl -O https://github.com/c4pt000/rtinst/raw/master/rtinst-master.zip
unzip rtinst-master.zip
